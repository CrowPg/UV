//
//  Reel.cpp
//  Nombres
//
//  Created by Johan Medioni on 04/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>

#include "Reel.h"

void Reel::afficher(){
    std::cout<<"\n"<<this->val<<std::endl;
}