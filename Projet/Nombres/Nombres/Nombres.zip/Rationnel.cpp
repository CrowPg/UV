//
//  Rationnel.cpp
//  Nombres
//
//  Created by Johan Medioni on 04/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>

#include "Rationnel.h"

void Rationnel::afficher(){
    std::cout<<"\n"<<this->num<<"/"<<this->den<<std::endl;
}